// src/seed.ts

import {
	type MockDb,
	type MockProgram,
	type MockRevision,
	type Vehicle,
	writeDb,
} from "./store.js";

const iso = (value: string) => new Date(value).toISOString();

const emptySetup = () => ({
	programName: null,
	programTypeCode: null,
	purchaseType: null,
	customerTypeCodes: [],
	contactName: null,
	contactEmail: null,
	contactPhone: null,
	financialProviderCode: null,
	conditionCode: null,
	mileageCeiling: null,
	topOfDeal: false,
	vinException: false,
	mfpnText: null,
	disclosureText: null,
	localeCode: "en-US",
	deliveryStartDate: null,
	deliveryEndDate: null,
	effectiveStartDate: null,
	effectiveEndDate: null,
	financeTerms: [],
	creditTiers: [],
});

const approval = (
	revisionId: number,
	overrides: Partial<MockRevision["approval"]> = {},
): MockRevision["approval"] => ({
	revisionId,

	isSubmitted: false,
	submittedAt: null,
	submittedBy: null,

	approved: false,
	approvedAt: null,
	approvedBy: null,

	approvalComment: null,

	rejectedAt: null,
	rejectedBy: null,

	rejectionReason: null,

	...overrides,
});

const vehicles: Vehicle[] = [
	{
		vehicleCatalogId: 1001,
		vehicleId: "GM:2026:SIL1500",
		year: 2026,
		make: "Chevrolet",
		model: "Silverado 1500",
		trimName: "LT",
		bodyStyle: "Crew Cab",
		segment: "Full-Size Truck",
		fuelType: "Gas",
		drivetrain: "4WD",
		oemCode: "GM",
	},

	{
		vehicleCatalogId: 1002,
		vehicleId: "GM:2026:EQUINOX",
		year: 2026,
		make: "Chevrolet",
		model: "Equinox",
		trimName: "LT",
		bodyStyle: "SUV",
		segment: "Compact SUV",
		fuelType: "Gas",
		drivetrain: "FWD",
		oemCode: "GM",
	},

	{
		vehicleCatalogId: 1003,
		vehicleId: "GM:2026:CT5",
		year: 2026,
		make: "Cadillac",
		model: "CT5",
		trimName: "Luxury",
		bodyStyle: "Sedan",
		segment: "Luxury Sedan",
		fuelType: "Gas",
		drivetrain: "RWD",
		oemCode: "GM",
	},

	{
		vehicleCatalogId: 1004,
		vehicleId: "GM:2026:LYRIQ",
		year: 2026,
		make: "Cadillac",
		model: "LYRIQ",
		trimName: "Tech",
		bodyStyle: "SUV",
		segment: "Luxury SUV",
		fuelType: "Electric",
		drivetrain: "AWD",
		oemCode: "GM",
	},

	{
		vehicleCatalogId: 2001,
		vehicleId: "GM:2026:TRAVERSE",
		year: 2026,
		make: "Chevrolet",
		model: "Traverse",
		trimName: "LT",
		bodyStyle: "SUV",
		segment: "Mid-Size SUV",
		fuelType: "Gas",
		drivetrain: "AWD",
		oemCode: "GM",
	},

	{
		vehicleCatalogId: 3001,
		vehicleId: "GM:2026:ESCALADE",
		year: 2026,
		make: "Cadillac",
		model: "Escalade",
		trimName: "Premium",
		bodyStyle: "SUV",
		segment: "Full-Size Luxury SUV",
		fuelType: "Gas",
		drivetrain: "4WD",
		oemCode: "GM",
	},

	{
		vehicleCatalogId: 5001,
		vehicleId: "IND:2026:F150",
		year: 2026,
		make: "Ford",
		model: "F-150",
		trimName: "XLT",
		bodyStyle: "Crew Cab",
		segment: "Full-Size Truck",
		fuelType: "Gas",
		drivetrain: "4WD",
		oemCode: "IND",
	},

	{
		vehicleCatalogId: 5002,
		vehicleId: "IND:2026:RAV4",
		year: 2026,
		make: "Toyota",
		model: "RAV4",
		trimName: "XLE",
		bodyStyle: "SUV",
		segment: "Compact SUV",
		fuelType: "Hybrid",
		drivetrain: "AWD",
		oemCode: "IND",
	},

	{
		vehicleCatalogId: 5003,
		vehicleId: "GM:2025:SIL1500",
		year: 2025,
		make: "Chevrolet",
		model: "Silverado 1500",
		trimName: "LT",
		bodyStyle: "Crew Cab",
		segment: "Full-Size Truck",
		fuelType: "Gas",
		drivetrain: "4WD",
		oemCode: "GM",
	},

	{
		vehicleCatalogId: 5004,
		vehicleId: "GM:2025:TAHOE",
		year: 2025,
		make: "Chevrolet",
		model: "Tahoe",
		trimName: "LT",
		bodyStyle: "SUV",
		segment: "Full-Size SUV",
		fuelType: "Gas",
		drivetrain: "4WD",
		oemCode: "GM",
	},

	{
		vehicleCatalogId: 5005,
		vehicleId: "GM:2024:CT4",
		year: 2024,
		make: "Cadillac",
		model: "CT4",
		trimName: "Luxury",
		bodyStyle: "Sedan",
		segment: "Luxury Sedan",
		fuelType: "Gas",
		drivetrain: "RWD",
		oemCode: "GM",
	},
];

const geography = {
	regions: [
		{
			code: "NORTHEAST",
			name: "Northeast",
		},
		{
			code: "MIDWEST",
			name: "Midwest",
		},
		{
			code: "SOUTH",
			name: "South",
		},
		{
			code: "WEST",
			name: "West",
		},
	],

	states: [
		{
			code: "NY",
			name: "New York",
			region: "NORTHEAST",
		},
		{
			code: "MA",
			name: "Massachusetts",
			region: "NORTHEAST",
		},
		{
			code: "PA",
			name: "Pennsylvania",
			region: "NORTHEAST",
		},
		{
			code: "MI",
			name: "Michigan",
			region: "MIDWEST",
		},
		{
			code: "OH",
			name: "Ohio",
			region: "MIDWEST",
		},
		{
			code: "IL",
			name: "Illinois",
			region: "MIDWEST",
		},
		{
			code: "FL",
			name: "Florida",
			region: "SOUTH",
		},
		{
			code: "TX",
			name: "Texas",
			region: "SOUTH",
		},
		{
			code: "GA",
			name: "Georgia",
			region: "SOUTH",
		},
		{
			code: "CA",
			name: "California",
			region: "WEST",
		},
		{
			code: "WA",
			name: "Washington",
			region: "WEST",
		},
		{
			code: "AZ",
			name: "Arizona",
			region: "WEST",
		},
	],

	dmas: [
		{
			code: "NYC",
			name: "New York",
			state: "NY",
			region: "NORTHEAST",
		},
		{
			code: "BOS",
			name: "Boston",
			state: "MA",
			region: "NORTHEAST",
		},
		{
			code: "PHL",
			name: "Philadelphia",
			state: "PA",
			region: "NORTHEAST",
		},
		{
			code: "DET",
			name: "Detroit",
			state: "MI",
			region: "MIDWEST",
		},
		{
			code: "CLE",
			name: "Cleveland",
			state: "OH",
			region: "MIDWEST",
		},
		{
			code: "CHI",
			name: "Chicago",
			state: "IL",
			region: "MIDWEST",
		},
		{
			code: "MIA",
			name: "Miami",
			state: "FL",
			region: "SOUTH",
		},
		{
			code: "DAL",
			name: "Dallas",
			state: "TX",
			region: "SOUTH",
		},
		{
			code: "ATL",
			name: "Atlanta",
			state: "GA",
			region: "SOUTH",
		},
		{
			code: "LAX",
			name: "Los Angeles",
			state: "CA",
			region: "WEST",
		},
		{
			code: "SEA",
			name: "Seattle",
			state: "WA",
			region: "WEST",
		},
		{
			code: "PHX",
			name: "Phoenix",
			state: "AZ",
			region: "WEST",
		},
	],

	counties: [
		{
			code: "NY001",
			name: "New York County",
			state: "NY",
			dma: "NYC",
		},
		{
			code: "NY003",
			name: "Kings County",
			state: "NY",
			dma: "NYC",
		},
		{
			code: "MA025",
			name: "Suffolk County",
			state: "MA",
			dma: "BOS",
		},
		{
			code: "PA101",
			name: "Philadelphia County",
			state: "PA",
			dma: "PHL",
		},
		{
			code: "MI163",
			name: "Wayne County",
			state: "MI",
			dma: "DET",
		},
		{
			code: "OH035",
			name: "Cuyahoga County",
			state: "OH",
			dma: "CLE",
		},
		{
			code: "IL031",
			name: "Cook County",
			state: "IL",
			dma: "CHI",
		},
		{
			code: "FL086",
			name: "Miami-Dade County",
			state: "FL",
			dma: "MIA",
		},
		{
			code: "TX113",
			name: "Dallas County",
			state: "TX",
			dma: "DAL",
		},
		{
			code: "GA121",
			name: "Fulton County",
			state: "GA",
			dma: "ATL",
		},
		{
			code: "CA037",
			name: "Los Angeles County",
			state: "CA",
			dma: "LAX",
		},
		{
			code: "WA033",
			name: "King County",
			state: "WA",
			dma: "SEA",
		},
		{
			code: "AZ013",
			name: "Maricopa County",
			state: "AZ",
			dma: "PHX",
		},
	],
};

const referenceSetup = {
	programTypes: [
		{
			code: "CUSTOMER_CASH",
			name: "Customer Cash",
			supportsCash: true,
			supportsRate: false,
		},
		{
			code: "APR",
			name: "APR",
			supportsCash: false,
			supportsRate: true,
		},
		{
			code: "BONUS_CASH",
			name: "Bonus Cash",
			supportsCash: true,
			supportsRate: false,
		},
	],

	purchaseTypes: [
		{
			code: "CASH",
			name: "Cash",
		},
		{
			code: "FINANCE",
			name: "Finance",
		},
	],

	customerTypes: [
		{
			code: "STANDARD",
			name: "Standard",
		},
		{
			code: "LOYALTY",
			name: "Loyalty",
		},
		{
			code: "CONQUEST",
			name: "Conquest",
		},
	],

	conditionCodes: [
		{
			code: "CARBRAVO",
			name: "CarBravo",
		},
		{
			code: "MANUFACTURER_CERTIFIED",
			name: "Manufacturer Certified",
		},
		{
			code: "USED_INSPECTED",
			name: "Used Inspected",
		},
		{
			code: "USED_AS_IS",
			name: "Used As-Is",
		},
	],

	financeTermOptions: [
		{
			termMonths: 24,
			label: "24 Months",
		},
		{
			termMonths: 36,
			label: "36 Months",
		},
		{
			termMonths: 48,
			label: "48 Months",
		},
		{
			termMonths: 60,
			label: "60 Months",
		},
		{
			termMonths: 72,
			label: "72 Months",
		},
	],

	creditTierOptions: [
		{
			code: "A_PLUS",
			name: "A+",
			sortOrder: 1,
		},
		{
			code: "A1",
			name: "A1",
			sortOrder: 2,
		},
		{
			code: "A2",
			name: "A2",
			sortOrder: 3,
		},
		{
			code: "B",
			name: "B",
			sortOrder: 4,
		},
	],

	financialProviders: [
		{
			code: "GM_FINANCIAL",
			name: "GM Financial",
			isActive: true,
			supportedTerms: [24, 36, 48, 60, 72],
			supportsCash: false,
			supportsRate: true,
		},
		{
			code: "CHASE",
			name: "Chase",
			isActive: true,
			supportedTerms: [36, 48, 60, 72],
			supportsCash: false,
			supportsRate: true,
		},
		{
			code: "ALLY",
			name: "Ally",
			isActive: true,
			supportedTerms: [36, 48, 60],
			supportsCash: false,
			supportsRate: true,
		},
		{
			code: "GMF",
			name: "GM Financial",
			isActive: true,
			supportedTerms: [24, 36, 48, 60],
			supportsCash: false,
			supportsRate: true,
		},
	],
};

function revisionBase(
	id: number,
	programId: number,
	majorRevision: number,
	minorRevision: number,
): MockRevision {
	return {
		id,

		programId,

		majorRevision,

		minorRevision,

		status: "DRAFT",

		isMinorRevision: false,

		createdAt: iso("2026-08-10T09:00:00Z"),

		createdBy: "jsmith",

		postedAt: null,

		postedBy: null,

		approval: approval(id),

		setup: emptySetup(),

		vehicles: [],

		geography: [],

		values: {
			financeTerms: [],
			components: [],
		},

		summary: {},

		copiedFromRevisionId: null,
	};
}

const programs: MockProgram[] = [
	{
		id: 1,
		identifier: "PROG-2026-0001",
		name: "Summer Finance Event",
		status: "ACTIVE",
		programType: "APR",

		activeRevisionId: 101,
		draftRevisionId: null,

		deliveryStartDate: "2026-07-01",

		deliveryEndDate: "2026-08-20",

		createdAt: iso("2026-06-01T10:00:00Z"),

		updatedAt: iso("2026-08-13T05:30:00Z"),

		deletedAt: null,
	},

	{
		id: 2,
		identifier: "PROG-2026-0002",
		name: "EV Bonus Cash",
		status: "ACTIVE",
		programType: "BONUS_CASH",

		activeRevisionId: 102,
		draftRevisionId: null,

		deliveryStartDate: "2026-07-15",

		deliveryEndDate: "2026-08-25",

		createdAt: iso("2026-06-10T10:00:00Z"),

		updatedAt: iso("2026-08-13T07:30:00Z"),

		deletedAt: null,
	},

	{
		id: 3,
		identifier: "PROG-2026-0003",
		name: "Cadillac Loyalty APR",
		status: "EXPIRED",
		programType: "APR",

		activeRevisionId: 103,
		draftRevisionId: null,

		deliveryStartDate: "2026-06-01",

		deliveryEndDate: "2026-08-28",

		createdAt: iso("2026-05-01T10:00:00Z"),

		updatedAt: iso("2026-08-01T09:00:00Z"),

		deletedAt: null,
	},

	{
		id: 4,
		identifier: "PROG-2026-0004",
		name: "Non-GM Certified Cash",
		status: "DRAFT",
		programType: "CUSTOMER_CASH",

		activeRevisionId: null,
		draftRevisionId: 104,

		deliveryStartDate: "2026-09-01",

		deliveryEndDate: "2026-09-30",

		createdAt: iso("2026-08-12T10:00:00Z"),

		updatedAt: iso("2026-08-13T08:20:00Z"),

		deletedAt: null,
	},

	{
		id: 5,
		identifier: "PROG-2026-0005",
		name: "Q3 Customer Cash",
		status: "DRAFT",
		programType: "CUSTOMER_CASH",

		activeRevisionId: null,
		draftRevisionId: 105,

		deliveryStartDate: "2026-09-01",

		deliveryEndDate: "2026-11-30",

		createdAt: iso("2026-08-12T09:00:00Z"),

		updatedAt: iso("2026-08-12T09:00:00Z"),

		deletedAt: null,
	},

	{
		id: 6,
		identifier: "PROG-2026-0006",
		name: "Northeast APR Special",
		status: "ACTIVE",
		programType: "APR",

		activeRevisionId: 106,
		draftRevisionId: 107,

		deliveryStartDate: "2026-06-01",

		deliveryEndDate: "2026-12-31",

		createdAt: iso("2026-05-28T09:00:00Z"),

		updatedAt: iso("2026-08-10T12:00:00Z"),

		deletedAt: null,
	},
];

const revisions: MockRevision[] = [];

/* ============================================================
 * REVISION 101
 * Program 1 - ACTIVE
 * ============================================================ */

{
	const revision = revisionBase(101, 1, 2, 0);

	revision.status = "ACTIVE";

	revision.createdAt = iso("2026-06-01T10:00:00Z");

	revision.createdBy = "admin";

	revision.postedAt = iso("2026-07-01T10:00:00Z");

	revision.postedBy = "admin";

	revision.approval = approval(101, {
		isSubmitted: true,
		submittedAt: iso("2026-06-20T10:00:00Z"),
		submittedBy: "jsmith",

		approved: true,
		approvedAt: iso("2026-06-25T10:00:00Z"),
		approvedBy: "mreviewer",

		approvalComment: "Approved",
	});

	revision.setup = {
		...emptySetup(),

		programName: "Summer Finance Event",

		programTypeCode: "APR",

		purchaseType: "FINANCE",

		customerTypeCodes: ["STANDARD", "LOYALTY"],

		contactName: "Jordan Smith",

		contactEmail: "jsmith@example.com",

		contactPhone: "555-1000",

		financialProviderCode: "GM_FINANCIAL",

		conditionCode: "CARBRAVO",

		mileageCeiling: 75000,

		topOfDeal: true,

		mfpnText: "Not all buyers will qualify. See dealer for details.",

		disclosureText: "Offer valid on approved credit through GM Financial.",

		deliveryStartDate: "2026-07-01",

		deliveryEndDate: "2026-08-20",

		effectiveStartDate: "2026-07-01",

		effectiveEndDate: "2026-08-20",

		financeTerms: [36, 48, 60],

		creditTiers: ["A_PLUS", "A1"],
	};

	revision.vehicles = [
		{
			revisionVehicleId: 1,
			vehicleCatalogId: 1001,
		},
	];

	revision.geography = [
		{
			geoRuleId: 1,
			isIncluded: true,
			level: "STATE",
			code: "CA",
			name: "California",
		},
		{
			geoRuleId: 2,
			isIncluded: true,
			level: "STATE",
			code: "TX",
			name: "Texas",
		},
		{
			geoRuleId: 3,
			isIncluded: true,
			level: "STATE",
			code: "FL",
			name: "Florida",
		},
	];

	revision.values = {
		financeTerms: [36, 48, 60],

		components: [
			{
				componentId: 1,
				componentCode: "TERM_36",
				componentName: "36 Month APR",
				sequenceNo: 1,
				attributes: [
					{
						attributeId: 1,
						key: "TERM_MONTHS",
						numberValue: 36,
						textValue: null,
					},
					{
						attributeId: 2,
						key: "APR_RATE",
						numberValue: 2.9,
						textValue: null,
					},
				],
				vehicleOverrides: [],
			},
		],
	};

	revision.summary = {
		mfpnText: revision.setup.mfpnText,

		disclosureText: revision.setup.disclosureText,
	};

	revisions.push(revision);
}

/* ============================================================
 * REVISION 102
 * Program 2 - ACTIVE
 * ============================================================ */

{
	const revision = revisionBase(102, 2, 1, 0);

	revision.status = "ACTIVE";

	revision.createdAt = iso("2026-06-10T10:00:00Z");

	revision.createdBy = "admin";

	revision.postedAt = iso("2026-07-15T10:00:00Z");

	revision.postedBy = "admin";

	revision.approval = approval(102, {
		isSubmitted: true,
		submittedAt: iso("2026-07-01T10:00:00Z"),
		submittedBy: "jsmith",

		approved: true,
		approvedAt: iso("2026-07-05T10:00:00Z"),
		approvedBy: "mreviewer",

		approvalComment: "Approved",
	});

	revision.setup = {
		...emptySetup(),

		programName: "EV Bonus Cash",

		programTypeCode: "BONUS_CASH",

		purchaseType: "CASH",

		customerTypeCodes: ["STANDARD"],

		contactName: "Jamie Smith",

		contactEmail: "jamie.smith@carbravo.example",

		contactPhone: "555-0101",

		conditionCode: "CARBRAVO",

		mileageCeiling: 60000,

		mfpnText: "Bonus cash applied at time of sale.",

		disclosureText: "Not compatible with other offers.",

		deliveryStartDate: "2026-07-15",

		deliveryEndDate: "2026-08-25",

		effectiveStartDate: "2026-07-15",

		effectiveEndDate: "2026-08-25",
	};

	revision.vehicles = [
		{
			revisionVehicleId: 2,
			vehicleCatalogId: 1004,
		},
	];

	revision.geography = [
		{
			geoRuleId: 4,
			isIncluded: true,
			level: "STATE",
			code: "CA",
			name: "California",
		},
		{
			geoRuleId: 5,
			isIncluded: true,
			level: "STATE",
			code: "NY",
			name: "New York",
		},
		{
			geoRuleId: 6,
			isIncluded: true,
			level: "STATE",
			code: "WA",
			name: "Washington",
		},
	];

	revision.values = {
		financeTerms: [],

		components: [
			{
				componentId: 2,
				componentCode: "EV_BONUS",
				componentName: "EV Bonus Cash",
				sequenceNo: 1,
				attributes: [
					{
						attributeId: 3,
						key: "CASH_AMOUNT",
						numberValue: 1500,
						textValue: null,
					},
				],
				vehicleOverrides: [],
			},
		],
	};

	revision.summary = {
		mfpnText: revision.setup.mfpnText,

		disclosureText: revision.setup.disclosureText,
	};

	revisions.push(revision);
}

/* ============================================================
 * REVISION 103
 * Program 3 - EXPIRED
 * ============================================================ */

{
	const revision = revisionBase(103, 3, 1, 0);

	revision.status = "EXPIRED";

	revision.createdAt = iso("2026-07-15T09:00:00Z");

	revision.createdBy = "jsmith";

	revision.postedAt = iso("2026-07-22T09:00:00Z");

	revision.postedBy = "admin";

	revision.approval = approval(103, {
		isSubmitted: true,
		submittedAt: iso("2026-07-20T09:00:00Z"),
		submittedBy: "jsmith",

		approved: true,
		approvedAt: iso("2026-07-21T09:00:00Z"),
		approvedBy: "mreviewer",
	});

	revision.setup = {
		...emptySetup(),

		programName: "Cadillac Loyalty APR",

		programTypeCode: "APR",

		purchaseType: "FINANCE",

		customerTypeCodes: ["LOYALTY"],

		conditionCode: "MANUFACTURER_CERTIFIED",

		financialProviderCode: "ALLY",

		mileageCeiling: 50000,

		deliveryStartDate: "2026-06-01",

		deliveryEndDate: "2026-08-28",

		effectiveStartDate: "2026-06-01",

		effectiveEndDate: "2026-08-28",

		financeTerms: [36, 48],

		creditTiers: ["A_PLUS"],
	};

	revision.vehicles = [
		{
			revisionVehicleId: 3,
			vehicleCatalogId: 3001,
		},
	];

	revision.geography = [
		{
			geoRuleId: 7,
			isIncluded: true,
			level: "STATE",
			code: "CA",
			name: "California",
		},
		{
			geoRuleId: 8,
			isIncluded: true,
			level: "STATE",
			code: "TX",
			name: "Texas",
		},
	];

	revision.values = {
		financeTerms: [36, 48],

		components: [
			{
				componentId: 3,
				componentCode: "TERM_36",
				componentName: "36 Month APR",
				sequenceNo: 1,
				attributes: [
					{
						attributeId: 4,
						key: "TERM_MONTHS",
						numberValue: 36,
						textValue: null,
					},
					{
						attributeId: 5,
						key: "APR_RATE",
						numberValue: 1.9,
						textValue: null,
					},
				],
				vehicleOverrides: [],
			},
		],
	};

	revisions.push(revision);
}

/* ============================================================
 * REVISION 104
 * Program 4 - DRAFT / SUBMITTED
 * ============================================================ */

{
	const revision = revisionBase(104, 4, 1, 0);

	revision.createdAt = iso("2026-08-12T10:00:00Z");

	revision.approval = approval(104, {
		isSubmitted: true,
		submittedAt: iso("2026-08-13T08:20:00Z"),
		submittedBy: "jsmith",
	});

	revision.setup = {
		...emptySetup(),

		programName: "Non-GM Certified Cash",

		programTypeCode: "CUSTOMER_CASH",

		purchaseType: "CASH",

		customerTypeCodes: ["STANDARD", "CONQUEST"],

		conditionCode: "USED_INSPECTED",

		mileageCeiling: 80000,

		deliveryStartDate: "2026-09-01",

		deliveryEndDate: "2026-09-30",
	};

	revision.vehicles = [
		{
			revisionVehicleId: 4,
			vehicleCatalogId: 5001,
		},
	];

	revision.geography = [
		{
			geoRuleId: 9,
			isIncluded: true,
			level: "REGION",
			code: "SOUTH",
			name: "South",
		},
	];

	revision.values = {
		financeTerms: [],

		components: [
			{
				componentId: 4,
				componentCode: "FLAT_CASH",
				componentName: "Flat Customer Cash",
				sequenceNo: 1,
				attributes: [
					{
						attributeId: 6,
						key: "CASH_AMOUNT",
						numberValue: 1000,
						textValue: null,
					},
				],
				vehicleOverrides: [],
			},
		],
	};

	revisions.push(revision);
}

/* ============================================================
 * REVISION 105
 * Program 5 - untouched DRAFT
 * ============================================================ */

{
	const revision = revisionBase(105, 5, 1, 0);

	revision.createdAt = iso("2026-08-12T09:00:00Z");

	revision.setup = {
		...emptySetup(),

		programName: "Q3 Customer Cash",

		programTypeCode: "CUSTOMER_CASH",

		deliveryStartDate: "2026-09-01",

		deliveryEndDate: "2026-11-30",
	};

	revisions.push(revision);
}

/* ============================================================
 * REVISION 106
 * Program 6 - ACTIVE BASE
 * ============================================================ */

{
	const revision = revisionBase(106, 6, 1, 0);

	revision.status = "ACTIVE";

	revision.createdAt = iso("2026-05-28T09:00:00Z");

	revision.createdBy = "jsmith";

	revision.postedAt = iso("2026-06-01T13:00:00Z");

	revision.postedBy = "admin";

	revision.approval = approval(106, {
		isSubmitted: true,

		submittedAt: iso("2026-06-01T09:00:00Z"),

		submittedBy: "jsmith",

		approved: true,

		approvedAt: iso("2026-06-01T12:00:00Z"),

		approvedBy: "mreviewer",
	});

	revision.setup = {
		...emptySetup(),

		programName: "Northeast APR Special",

		programTypeCode: "APR",

		purchaseType: "FINANCE",

		customerTypeCodes: ["STANDARD"],

		conditionCode: "CARBRAVO",

		financialProviderCode: "CHASE",

		deliveryStartDate: "2026-06-01",

		deliveryEndDate: "2026-12-31",

		financeTerms: [48, 60],

		creditTiers: ["A1", "A2"],
	};

	revision.vehicles = [
		{
			revisionVehicleId: 5,
			vehicleCatalogId: 2001,
		},
	];

	revision.geography = [
		{
			geoRuleId: 10,
			isIncluded: true,
			level: "STATE",
			code: "NY",
			name: "New York",
		},
		{
			geoRuleId: 11,
			isIncluded: true,
			level: "STATE",
			code: "MA",
			name: "Massachusetts",
		},
	];

	revision.values = {
		financeTerms: [48, 60],

		components: [
			{
				componentId: 5,
				componentCode: "TERM_48",
				componentName: "48 Month APR",
				sequenceNo: 1,
				attributes: [
					{
						attributeId: 7,
						key: "TERM_MONTHS",
						numberValue: 48,
						textValue: null,
					},
					{
						attributeId: 8,
						key: "APR_RATE",
						numberValue: 3.9,
						textValue: null,
					},
				],
				vehicleOverrides: [],
			},
		],
	};

	revisions.push(revision);
}

/* ============================================================
 * REVISION 107
 * Program 6 - LIVE DRAFT
 * ============================================================ */

{
	const revision = revisionBase(107, 6, 2, 0);

	revision.createdAt = iso("2026-08-10T12:00:00Z");

	revision.createdBy = "jsmith";

	revision.copiedFromRevisionId = 106;

	revision.setup = {
		...emptySetup(),

		programName: "Northeast APR Special",

		programTypeCode: "APR",

		purchaseType: "FINANCE",

		customerTypeCodes: ["STANDARD"],

		conditionCode: "CARBRAVO",

		financialProviderCode: "CHASE",

		deliveryStartDate: "2026-06-01",

		deliveryEndDate: "2026-12-31",

		financeTerms: [48, 60, 72],

		creditTiers: ["A1", "A2"],
	};

	revision.vehicles = [
		{
			revisionVehicleId: 6,
			vehicleCatalogId: 2001,
		},
	];

	revision.geography = [
		{
			geoRuleId: 12,
			isIncluded: true,
			level: "STATE",
			code: "NY",
			name: "New York",
		},
		{
			geoRuleId: 13,
			isIncluded: true,
			level: "STATE",
			code: "MA",
			name: "Massachusetts",
		},
		{
			geoRuleId: 14,
			isIncluded: true,
			level: "STATE",
			code: "PA",
			name: "Pennsylvania",
		},
	];

	revision.values = {
		financeTerms: [48, 60, 72],

		components: [
			{
				componentId: 6,
				componentCode: "TERM_48",
				componentName: "48 Month APR",
				sequenceNo: 1,
				attributes: [
					{
						attributeId: 9,
						key: "TERM_MONTHS",
						numberValue: 48,
						textValue: null,
					},
					{
						attributeId: 10,
						key: "APR_RATE",
						numberValue: 3.49,
						textValue: null,
					},
				],
				vehicleOverrides: [],
			},
		],
	};

	revisions.push(revision);
}

/* ============================================================
 * ACTIVITY
 * ============================================================ */

const activity = [
	{
		id: 1,
		entityType: "INCENTIVE_REVISION" as const,
		entityId: 104,
		operation: "SUBMIT" as const,
		changedBy: "jsmith",
		changedAt: iso("2026-08-13T08:20:00Z"),
		programName: "Non-GM Certified Cash",
		programIdentifier: "PROG-2026-0004",
	},

	{
		id: 2,
		entityType: "INCENTIVE_REVISION" as const,
		entityId: 102,
		operation: "APPROVE" as const,
		changedBy: "mreviewer",
		changedAt: iso("2026-08-13T07:30:00Z"),
		programName: "EV Bonus Cash",
		programIdentifier: "PROG-2026-0002",
	},

	{
		id: 3,
		entityType: "INCENTIVE_PROGRAM" as const,
		entityId: 1,
		operation: "POST_TO_PRODUCTION" as const,
		changedBy: "admin",
		changedAt: iso("2026-08-13T05:30:00Z"),
		programName: "Summer Finance Event",
		programIdentifier: "PROG-2026-0001",
	},

	{
		id: 4,
		entityType: "INCENTIVE_PROGRAM" as const,
		entityId: 4,
		operation: "CREATE" as const,
		changedBy: "jsmith",
		changedAt: iso("2026-08-12T10:00:00Z"),
		programName: "Non-GM Certified Cash",
		programIdentifier: "PROG-2026-0004",
	},

	{
		id: 5,
		entityType: "INCENTIVE_REVISION" as const,
		entityId: 107,
		operation: "REVISE" as const,
		changedBy: "jsmith",
		changedAt: iso("2026-08-10T12:00:00Z"),
		programName: "Northeast APR Special",
		programIdentifier: "PROG-2026-0006",
	},
];

/* ============================================================
 * BUILD DB
 * ============================================================ */

const db: MockDb = {
	programs,

	revisions,

	vehicles,

	geography,

	referenceSetup,

	activity,
};

await writeDb(db);

console.log("✅ CarBravo seed completed");
console.log(`Programs: ${programs.length}`);
console.log(`Revisions: ${revisions.length}`);
console.log(`Vehicles: ${vehicles.length}`);
console.log(`Regions: ${geography.regions.length}`);
console.log(`States: ${geography.states.length}`);
console.log(`DMAs: ${geography.dmas.length}`);
console.log(`Counties: ${geography.counties.length}`);
console.log(`Activity: ${activity.length}`);
